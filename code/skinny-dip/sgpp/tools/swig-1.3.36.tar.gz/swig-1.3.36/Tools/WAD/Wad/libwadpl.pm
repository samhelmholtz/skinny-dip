package libwadpl;
require Exporter;
require DynaLoader;
@ISA = qw(Exporter DynaLoader);
package libwadpl;
bootstrap libwadpl;
@EXPORT = qw( );
1;
