#!/usr/bin/env ruby
#
# Put description here
#
# 
# 
# 
#

require 'swig_assert'

require 'overload_template'

f = Overload_template.foo()

a = Overload_template.max(3,4)
b = Overload_template.max(3.4,5.2)
